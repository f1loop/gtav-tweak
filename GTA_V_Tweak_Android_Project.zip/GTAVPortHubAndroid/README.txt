GTA V Tweak - Android Studio project (WebView preview wrapper)

This project wraps the included launcher preview HTML in a simple Android app shell.
The HTML includes a short loading screen and the supplied logo.

Build APK:
1. Open this folder in Android Studio.
2. Let Gradle sync complete.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

This is a launcher UI preview only; it does not install or launch GTA V, nor does it connect graphics settings to a game installation.
The APK has not been compiled in this environment (Android SDK/Gradle build tools unavailable here).
