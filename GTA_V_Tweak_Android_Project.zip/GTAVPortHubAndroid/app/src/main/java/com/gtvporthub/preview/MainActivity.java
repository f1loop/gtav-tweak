package com.gtvporthub.preview;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
public class MainActivity extends Activity {
 private WebView w;
 private void immersive(){ getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION); }
 @Override public void onCreate(Bundle b){ super.onCreate(b);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  if(Build.VERSION.SDK_INT>=28){ WindowManager.LayoutParams lp=getWindow().getAttributes(); lp.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES; getWindow().setAttributes(lp); }
  immersive();
  w=new WebView(this); w.setBackgroundColor(0xff0a0b0d); setContentView(w);
  w.setOverScrollMode(View.OVER_SCROLL_NEVER); w.setVerticalScrollBarEnabled(false); w.setHorizontalScrollBarEnabled(false);
  w.setLongClickable(false); w.setHapticFeedbackEnabled(false); w.setOnLongClickListener(new View.OnLongClickListener(){ public boolean onLongClick(View v){ return true; }});
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
  s.setTextZoom(100); s.setMediaPlaybackRequiresUserGesture(false); s.setUseWideViewPort(true); s.setLoadWithOverviewMode(false);
  w.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onWindowFocusChanged(boolean f){ super.onWindowFocusChanged(f); if(f) immersive(); }
 @Override public void onBackPressed(){
  w.evaluateJavascript("window.hwBack&&window.hwBack()", new ValueCallback<String>(){ public void onReceiveValue(String v){ if(!"true".equals(v)) finish(); }});
 }
}
